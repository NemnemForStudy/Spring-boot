package com.example.mythymleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MythymleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
